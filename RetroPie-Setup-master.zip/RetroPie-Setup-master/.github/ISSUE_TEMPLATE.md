Please start a topic on the RetroPie forum before opening an issue - https://retropie.org.uk/forum/

Once a problem has been verified on the forum, an issue can be opened here.

Please remove this text before posting.
