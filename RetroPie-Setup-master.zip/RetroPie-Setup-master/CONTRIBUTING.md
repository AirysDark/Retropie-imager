# How to contribute

## Support Requests vs Bug Reporting

Please use the GitHub for bug reports only. For help / support in using RetroPie and the emulators
it ships with, please use the [RetroPie forum](https://retropie.org.uk/forum/).

## Pull Requests

Contributions to the project are welcome - please check out our [Shell Style Guide](https://retropie.org.uk/docs/Shell-Style-Guide/) before submitting changes.
